//require('dotenv').config();

const assert = require('assert');
const logger = require('./lib/logger');

const express = require('express');
const app = express();
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const mysqlUtility = require('./lib/db/mysql').MySQLUtility
const appUtility = require('./lib/utils/utility').AppUtility
const PORT = process.env.SERVER_PORT || 1111
const request = require('request');
const fs = require('fs')
const bodyParser = require('body-parser')

assert.ok(process.env.RTP_SERVER_MYSQL_HOST &&
    process.env.RTP_SERVER_MYSQL_PORT &&
    process.env.RTP_SERVER_MYSQL_USER &&
    process.env.RTP_SERVER_MYSQL_PASSWORD &&
    process.env.RTP_SERVER_MYSQL_DATABASE, 'missing RTP_SERVER_MYSQL_XXX env vars');

const limiter = rateLimit({
    windowMs: (process.env.RATE_LIMIT_WINDOWS_MINS || 5) * 60 * 1000, // 5 minutes
    max: process.env.RATE_LIMIT_MAX_PER_WINDOW || 600, // Limit each IP to 600 requests per `window`
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    });

app.use(limiter);
app.use(helmet());
app.use(helmet.hidePoweredBy());
app.use(cors());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
  parameterLimit: 100000,
  limit: '50mb',
  extended: true
}))

// parse application/json
app.use(bodyParser.json())

app.use((req, res, next) => {
  // authentication middleware

  const auth = {login: process.env.BASIC_AUTH_USERNAME, password: process.env.BASIC_AUTH_PASSWORD}

  // parse login and password from headers
  const b64auth = (req.headers.authorization || '').split(' ')[1] || ''
  const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':')

  // Verify login and password are set and correct
  if (login && password && login === auth.login && password === auth.password) {
    // Access granted...
    return next()
  }
  logger.info(`Authentication issue and the auth headers sent in the request ${req.headers.authorization}`)
  res.status(401).send({status: 'error', msg: 'Authentication required'}) // custom message
})

app.get(`/recording/:callId`, async (req, res) => {
    try{
        const callId = req.params && req.params['callId']
        if(!callId){
            return res.status(400).send({status: 'error', msg: `No callId is provided to get the recordings`})
        }
        logger.info(`Trying to fetch recording for call Id ${callId}`)
        let RecordingPaths = await mysqlUtility.getRecordingPaths(callId)
        if(RecordingPaths && RecordingPaths.status === 'error'){
          return res.status(RecordingPaths.errorCode).send({status: 'error', msg: RecordingPaths.msg})
        }
        logger.info(`Targeted recording path is ${RecordingPaths[0]}`)
        let filePathComponents = RecordingPaths[0] && RecordingPaths[0].split('/')
        let len = filePathComponents.length
        let targetedIPAddress
        for(let i = 0; i < len; i++){
          if(filePathComponents[i]){
            let currentPathComponent = filePathComponents[i].trim()
            let isIPAddress = appUtility.checkIfValidIP(currentPathComponent)
            if(isIPAddress){
              targetedIPAddress = currentPathComponent
              break
            }
          }
        }
        if(!targetedIPAddress){
          logger.error('No host IP is available to get the recording')
          return res.status(404).send({status: 'error', msg: 'No host IP is available to get the recording'})
        }
        logger.info(`URL for retrieving the recording is http://${targetedIPAddress}:${PORT}/fileData`)
        var token = "Basic " + Buffer.from(process.env.BASIC_AUTH_USERNAME + ":" + process.env.BASIC_AUTH_PASSWORD).toString('base64');
        request({
          headers: {'content-type' : 'application/json', 'Authorization': token},
          method: 'POST',
          url:     `http://${targetedIPAddress}:${PORT}/fileData`,
          body:   JSON.stringify({recordingPaths: RecordingPaths})
        }, function(error, response, body){
          if(error || !body){
            logger.error({ error }, `Something went wrong in retrieving call recording details`);
            return ({status: 'error', errorCode: 500,  msg: `Something went wrong in retrieving call recording details`}) 
          }
          res.status(200).send(body)
        });
    }catch(error){
      logger.error({ error }, `Something went wrong in retrieving call recording details`);
      return ({status: 'error', errorCode: 500,  msg: `Something went wrong in retrieving call recording details`}) 
    }
})

// make promise version of fs.readFile()
fs.readFileAsync = function(filename) {
  return new Promise(function(resolve, reject) {
      fs.readFile(filename, function(err, data){
          if (err) 
              reject(err); 
          else 
              resolve(data);
      });
  });
};

function getRecording(recordingPath) {
  return fs.readFileAsync(recordingPath);
}

function getAllRecordings(recordingPaths){
    let promiseArr = []
    let len = recordingPaths.length
    for (var i = 0; i <= len; i++) {
        if(recordingPaths[i]){
          promiseArr.push(getRecording(recordingPaths[i]));
        }        
    }
    return Promise.all(promiseArr);
}

app.post('/fileData', (req, res) => {
    try{
        const recordingPaths = req.body && req.body['recordingPaths']
        if(!recordingPaths){
            logger.error(`No recording path(s) is(are) provided to get the recordings`)
            return res.status(400).send({status: 'error', msg: `No recording path(s) is(are) provided to get the recordings`})
        }
        getAllRecordings(recordingPaths).then(function(recordingData) {
          let encodedDataArr = []
          if(!Array.isArray(recordingData)){
            logger.error(`Recording Data array is unavailable`);
            return ({status: 'error', errorCode: 500,  msg: `Something went wrong in retrieving call recordings`}) 
          }
          let len = recordingData.length
          for(let i = 0; i < len; i++){
            let base64Str = Buffer.from(recordingData[i]).toString('base64')
            if(base64Str){
              encodedDataArr.push(base64Str)
            }
          }
          return res.status(200).send({
            "recording" : encodedDataArr
        })
       }, function(error) {
        logger.error(`Something went wrong in retrieving call recording ${error}`);
        return ({status: 'error', errorCode: 500,  msg: `Something went wrong in retrieving call recordings`}) 
       });
    }catch(error){
      logger.error({ error }, `Something went wrong in retrieving call recordings`);
      return ({status: 'error', errorCode: 500,  msg: `Something went wrong in retrieving call recordings`}) 
    }
})

app.listen(PORT, () => {
    logger.info(`listening for HTTP traffic on port ${PORT}`);
})
